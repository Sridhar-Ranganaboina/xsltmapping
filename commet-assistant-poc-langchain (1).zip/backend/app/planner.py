
import os, json, re
from typing import List, Dict, Any
from .models import PlanModel, ActionModel
from .settings import settings

try:
    from .llm import build_chat_llm
    from langchain.schema import SystemMessage, HumanMessage
    LANGCHAIN_AVAILABLE = True
except Exception:
    LANGCHAIN_AVAILABLE = False

def _rule_based_plan(task: str, dom_snapshot: List[Dict[str, Any]]) -> PlanModel:
    steps = []
    url_match = re.search(r"https?://[^\s]+", task)
    if url_match:
        steps.append(ActionModel(action='navigate', url=url_match.group(0)))
        return PlanModel(steps=steps)
    for el in dom_snapshot:
        text = (el.get('text') or '').lower()
        if 'message' in text or 'send message' in text:
            selector = el.get('selector')
            if selector:
                steps.append(ActionModel(action='click', selector=selector))
                steps.append(ActionModel(action='type', selector='textarea, input[type="text"]', text=f"Hi — {task}"))
                steps.append(ActionModel(action='click', selector='button[type="submit"], button.send'))
                return PlanModel(steps=steps)
    steps.append(ActionModel(action='navigate', url='https://www.example.com/'))
    return PlanModel(steps=steps)

async def generate_plan(task: str, dom_snapshot: List[Dict[str, Any]]) -> PlanModel:
    if LANGCHAIN_AVAILABLE and (getattr(settings, 'openai_api_key', None) or os.environ.get('OPENAI_API_KEY')):
        try:
            llm = build_chat_llm()
            system = SystemMessage(content=(
                "You are a browser automation planner. Given a short task and a DOM snapshot, return a SHORT JSON plan (1-6 steps)."
                "Each step must be one of: navigate, click, type, waitForText, scroll, explore, done. Output only JSON with structure {\\"steps\\": [ ... ] }"
            ))
            user = HumanMessage(content=f"Task: {task}\nDOM: {json.dumps(dom_snapshot[:200])}")
            resp = llm([system, user])
            if isinstance(resp, list):
                text = getattr(resp[0], 'content', str(resp[0]))
            else:
                text = getattr(resp, 'content', str(resp))
            parsed = json.loads(text)
            steps = [ActionModel(**s) for s in parsed.get('steps', [])]
            return PlanModel(steps=steps)
        except Exception as e:
            print('LangChain plan failed:', e)
    return _rule_based_plan(task, dom_snapshot)
