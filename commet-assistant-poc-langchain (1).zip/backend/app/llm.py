
# app/llm.py - LangChain LLM builder (supports bearer token via OPENAI_API_KEY)
import os
from typing import Optional
from .settings import settings

try:
    from langchain.chat_models import ChatOpenAI
except Exception as e:
    ChatOpenAI = None

def build_chat_llm(bearer_token: Optional[str] = None):
    """Build a LangChain ChatOpenAI instance.
    - If bearer_token provided, it's set as OPENAI_API_KEY (works for OpenAI and many gateways).
    - If settings has openai_api_key it will be used as fallback.
    - Supports setting OPENAI_API_BASE / azure settings via environment or Settings (optional).
    """
    key = bearer_token or getattr(settings, 'openai_api_key', None)
    if key:
        os.environ['OPENAI_API_KEY'] = key

    if ChatOpenAI is None:
        raise RuntimeError('langchain not installed; please install langchain and openai packages')

    kwargs = {
        'model_name': getattr(settings, 'openai_model', 'gpt-4o-mini'),
        'temperature': 0.0,
    }
    base = os.environ.get('OPENAI_API_BASE') or getattr(settings, 'openai_api_base', None)
    if base:
        kwargs['openai_api_base'] = base
        api_type = os.environ.get('OPENAI_API_TYPE') or getattr(settings, 'openai_api_type', None)
        api_version = os.environ.get('OPENAI_API_VERSION') or getattr(settings, 'openai_api_version', None)
        deployment = os.environ.get('OPENAI_DEPLOYMENT') or getattr(settings, 'openai_deployment', None)
        if api_type:
            kwargs['openai_api_type'] = api_type
        if api_version:
            kwargs['openai_api_version'] = api_version
        if deployment:
            kwargs['deployment_name'] = deployment

    return ChatOpenAI(**kwargs)
