
const BACKEND = 'http://localhost:8000';
function sleep(ms){ return new Promise(r=>setTimeout(r, ms)); }
function getSnapshotFromActiveTab(){ return new Promise(async (resolve)=>{ const [tab] = await chrome.tabs.query({ active:true, currentWindow:true }); chrome.tabs.sendMessage(tab.id, { type: 'GET_SNAPSHOT' }, (resp) => { resolve({ snapshot: resp && resp.snapshot ? resp.snapshot : null, tabId: tab.id, url: tab?.url }); }); }); }
async function sendToBackend(path, payload){ const res = await fetch(`${BACKEND}${path}`, { method: 'POST', headers: { 'Content-Type':'application/json' }, body: JSON.stringify(payload) }); return res.json(); }
async function executePlan(steps, tabId){ for (let s of steps){ const resp = await new Promise(resolve => { chrome.tabs.sendMessage(tabId, { type: 'PERFORM_ACTION', action: s }, (r) => { resolve(r); }); }); await sleep(1000); const snapResp = await new Promise(resolve => { chrome.tabs.sendMessage(tabId, { type: 'GET_SNAPSHOT' }, (r) => resolve(r && r.snapshot ? r.snapshot : null)); }); try{ await fetch(`${BACKEND}/explore`, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ current_url: snapResp.url, links: snapResp.links || [] }) }); }catch(e){} try{ const nextPlan = await sendToBackend('/next', { last_step: s, dom: snapResp.controls, current_url: snapResp.url, prompt: currentTask }); if (nextPlan && nextPlan.steps && nextPlan.steps.length){ await executePlan(nextPlan.steps, tabId); } }catch(e){ console.error('Error /next:', e); } if (s.action === 'done') return; } }
let currentTask = null;
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg.type === 'START_TASK') {
      currentTask = msg.prompt;
      const { snapshot, tabId, url } = await getSnapshotFromActiveTab();
      const plan = await sendToBackend('/plan', { prompt: currentTask, dom: snapshot.controls, start_url: url });
      if (plan && plan.steps) {
        await executePlan(plan.steps, tabId);
      }
      sendResponse({ ok: true });
      return;
    }
    if (msg.type === 'RUN_AGENT') {
      const { agent, context } = msg;
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      try {
        const res = await fetch(`${BACKEND}/run_agent`, { method: 'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ agent, context }) });
        const data = await res.json();
        if (data && data.result && data.result.actions) {
          for (const a of data.result.actions) {
            await new Promise(resolve => { chrome.tabs.sendMessage(tab.id, { type: 'PERFORM_ACTION', action: a }, (r) => resolve(r)); });
            await sleep(800);
          }
        }
        sendResponse({ ok: true, result: data });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
      return;
    }
    if (msg.type === 'SUMMARIZE') {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      chrome.tabs.sendMessage(tab.id, { type: 'SUMMARIZE' }, async (resp) => {
        if (!resp || !resp.context) { sendResponse({ ok: false }); return; }
        try {
          const r = await fetch(`${BACKEND}/summarize`, { method: 'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ context: resp.context }) });
          const j = await r.json();
          sendResponse({ ok: true, summary: j });
        } catch (e){ sendResponse({ ok: false, error: String(e) }); }
      });
      return;
    }
    sendResponse({ ok: false });
  })();
  return true;
});
