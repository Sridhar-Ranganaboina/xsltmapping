
document.addEventListener('DOMContentLoaded', async () => {
  const start = document.getElementById('start');
  const summarize = document.getElementById('summarize');
  const status = document.getElementById('status');
  const task = document.getElementById('task');
  const bookmarksEl = document.getElementById('bookmarks');
  const runBookmark = document.getElementById('run-bookmark');

  start.addEventListener('click', () => {
    const prompt = task.value.trim();
    if (!prompt) { alert('Enter a task'); return; }
    chrome.runtime.sendMessage({ type: 'START_TASK', prompt }, (resp) => {
      status.textContent = resp?.ok ? 'Started' : 'Error';
    });
  });

  summarize.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'SUMMARIZE' }, (resp) => {
      // background will fetch summary and return
      chrome.runtime.onMessage.addListener(function handler(msg, _sender) {
        // no-op here, response comes via callback below
      });
      // Actually send via background which returns result to callback in background
      chrome.runtime.sendMessage({ type: 'SUMMARIZE' }, (r) => {
        if (r && r.summary) {
          alert('Summary:\n' + JSON.stringify(r.summary, null, 2));
        } else if (r && r.error) {
          alert('Summary failed: ' + r.error);
        }
      });
    });
  });

  // load bookmarks from backend
  async function loadBookmarks() {
    try {
      const res = await fetch('http://localhost:8000/bookmarks');
      const j = await res.json();
      bookmarksEl.innerHTML = '';
      (j.bookmarks || []).forEach(b => {
        const o = document.createElement('option');
        o.value = b.id; o.textContent = b.name;
        bookmarksEl.appendChild(o);
      });
    } catch (e) {
      bookmarksEl.innerHTML = '<option>Error loading</option>';
    }
  }
  await loadBookmarks();

  runBookmark.addEventListener('click', () => {
    const id = bookmarksEl.value;
    if (!id) return alert('Choose bookmark');
    chrome.runtime.sendMessage({ type: 'RUN_AGENT', agent: 'create_change_request', context: { values: {} } }, (r) => {
      alert('Bookmark run: ' + JSON.stringify(r));
    });
  });
});
