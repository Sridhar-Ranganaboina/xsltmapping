
// extension/content.js - snapshot + performAction + message handlers
function cssPath(el) {
  if (!el || el.nodeType !== 1) return '';
  if (el.id) return `#${CSS.escape(el.id)}`;
  const parts = [];
  while (el && el.nodeType === 1 && el !== document.body) {
    let selector = el.nodeName.toLowerCase();
    if (el.classList && el.classList.length) {
      selector += '.' + [...el.classList].map(c => CSS.escape(c)).join('.');
    }
    const parent = el.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children).filter(n => n.nodeName === el.nodeName);
      if (siblings.length > 1) {
        const index = siblings.indexOf(el) + 1;
        selector += `:nth-of-type(${index})`;
      }
    }
    parts.unshift(selector);
    el = el.parentElement;
  }
  return parts.length ? parts.join(' > ') : 'body';
}

function accessibleName(el) {
  const aria = el.getAttribute && el.getAttribute('aria-label');
  if (aria) return aria.trim();
  if (el.id) {
    const lab = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
    if (lab) return lab.innerText.trim();
  }
  const title = el.getAttribute && el.getAttribute('title');
  if (title) return title.trim();
  const text = el.innerText && el.innerText.trim();
  if (text) return text;
  const alt = el.getAttribute && el.getAttribute('alt');
  if (alt) return alt;
  return '';
}

function rect(el) {
  const r = el.getBoundingClientRect();
  return { x: r.x, y: r.y, width: r.width, height: r.height };
}

function snapshotPage() {
  const controls = Array.from(document.querySelectorAll('a[href], button, input, textarea, select, [role]')).map(el => {
    return {
      tag: el.tagName.toLowerCase(),
      text: (el.innerText || el.value || '').trim(),
      role: el.getAttribute('role') || null,
      href: el.getAttribute('href') || null,
      selector: cssPath(el),
      rect: rect(el)
    };
  });

  const links = controls.filter(c => c.tag === 'a' && c.href).map(c => new URL(c.href, window.location.href).href);

  return {
    url: window.location.href,
    title: document.title,
    origin: window.location.origin,
    controls,
    links: Array.from(new Set(links))
  };
}

async function performAction(action) {
  try {
    if (!action || !action.action) return { ok: false, error: 'invalid action' };
    switch (action.action) {
      case 'navigate':
        window.location.href = action.url;
        return { ok: true };
      case 'click': {
        const el = document.querySelector(action.selector);
        if (!el) return { ok: false, error: 'selector-not-found' };
        el.scrollIntoView({ block: 'center', inline: 'center' });
        el.click();
        return { ok: true };
      }
      case 'type': {
        const el = document.querySelector(action.selector);
        if (!el) return { ok: false, error: 'selector-not-found' };
        el.focus();
        if ('value' in el) {
          el.value = action.text || '';
          el.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
          el.innerText = action.text || '';
        }
        return { ok: true };
      }
      case 'scroll': {
        const times = action.times || 1;
        for (let i = 0; i < times; i++) {
          window.scrollBy(0, action.direction === 'up' ? -600 : 600);
          await new Promise(r => setTimeout(r, 400));
        }
        return { ok: true };
      }
      case 'waitForText': {
        const timeout = action.timeout || 8000;
        const start = Date.now();
        while (Date.now() - start < timeout) {
          if (document.body && document.body.innerText.includes(action.text)) return { ok: true };
          await new Promise(r => setTimeout(r, 300));
        }
        return { ok: false, error: 'wait-timeout' };
      }
      case 'explore': {
        const el = document.querySelector(action.selector);
        if (el) {
          el.scrollIntoView({ block: 'center' });
          el.click();
          return { ok: true };
        }
        return { ok: false, error: 'selector-not-found' };
      }
      case 'done':
        return { ok: true, done: true };
      default:
        return { ok: false, error: 'unknown-action' };
    }
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}

// message listener
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg.type === 'GET_SNAPSHOT') {
      sendResponse({ ok: true, snapshot: snapshotPage() });
      return;
    }
    if (msg.type === 'PERFORM_ACTION') {
      const res = await performAction(msg.action);
      sendResponse(res);
      return;
    }
    if (msg.type === 'SUMMARIZE') {
      const snap = snapshotPage();
      const pageText = document.body && document.body.innerText ? document.body.innerText.slice(0, 20000) : '';
      sendResponse({ ok: true, context: { url: snap.url, title: snap.title, controls: snap.controls, text: pageText } });
      return;
    }
    if (msg.type === 'RUN_AGENT') {
      const agent = msg.agent;
      const context = msg.context || {};
      // forward to background for backend call
      sendResponse({ ok: true, note: 'background will run agent' });
      return;
    }
    sendResponse({ ok: false, error: 'unknown-message' });
  })();
  return true;
});
