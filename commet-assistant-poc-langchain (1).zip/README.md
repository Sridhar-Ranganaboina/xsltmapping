
# Commet Assistant PoC — Extended (Summarizer + Agent Framework)

## Structure
See project tree in the root of this zip.

## Quick start (backend)
1. cd backend
2. Create a `.env` if you want to enable OpenAI: `OPENAI_API_KEY=...`
3. Install dependencies (recommended: Poetry):
   - `poetry install`
   - or create a virtualenv and `pip install fastapi uvicorn sqlmodel pydantic`
4. Run the backend:
   - `poetry run commet-backend` or `uvicorn app.main:app --reload --port 8000`

## Chrome extension
1. Open `chrome://extensions/` (Developer mode)
2. Load unpacked and select the `extension/` folder from this repo
3. Open a page you control and use the popup to start tasks or summarize the page

## Widget
You can include `widget/dist/commet-widget.js` on any page you control and set `window.COMMET_BACKEND` before including it to point to your backend.

## Notes
- This is a PoC. Do not use against sites you don't own or without permission.
- Add new agents by creating a file under `backend/app/agents/` that uses the `@register` decorator from `base.py` and implements `async def run(self, context)`.

