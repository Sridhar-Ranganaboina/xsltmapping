const BACKEND = "http://localhost:8000";
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
async function sendToBackend(path,payload){
  const res=await fetch(BACKEND+path,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  return res.json();
}
chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
  (async()=>{
    if(msg.type==="RUN_AUTOMATION"){
      const {task,tabId}=msg;
      chrome.tabs.sendMessage(tabId,{type:"GET_SNAPSHOT"},async resp=>{
        const snap=resp?.snapshot;
        const plan=await sendToBackend("/plan",{prompt:task,dom:snap.controls,start_url:snap.url});
        for(const step of plan.steps){
          await chrome.tabs.sendMessage(tabId,{type:"PERFORM_ACTION",action:step});
          await sleep(1200);
        }
        sendResponse({ok:true,steps:plan.steps});
      });
    }
    if(msg.type==="RUN_SUMMARY"){
      const {tabId}=msg;
      chrome.tabs.sendMessage(tabId,{type:"GET_SNAPSHOT"},async resp=>{
        const snap=resp?.snapshot;
        const result=await sendToBackend("/summarize",snap);
        sendResponse(result);
      });
    }
    if(msg.type==="RUN_BOOKMARK"){
      const {bookmark,tabId}=msg;
      const plan=await sendToBackend("/run_bookmark",{bookmark});
      for(const step of plan.steps||[]){
        await chrome.tabs.sendMessage(tabId,{type:"PERFORM_ACTION",action:step});
        await sleep(1200);
      }
      sendResponse({ok:true});
    }
  })();
  return true;
});
