function cssPath(el){if(!el||el.nodeType!==1)return'';if(el.id)return`#${CSS.escape(el.id)}`;const parts=[];
  while(el&&el.nodeType===1&&el!==document.body){let sel=el.nodeName.toLowerCase();
  if(el.classList?.length)sel+='.'+[...el.classList].map(c=>CSS.escape(c)).join('.');
  const parent=el.parentElement;if(parent){const siblings=Array.from(parent.children).filter(n=>n.nodeName===el.nodeName);
  if(siblings.length>1)sel+=`:nth-of-type(${siblings.indexOf(el)+1})`;}parts.unshift(sel);el=el.parentElement;}
  return parts.join(' > ');}
function snapshotPage(){
  const controls=Array.from(document.querySelectorAll("a,button,input,textarea,select")).map(el=>({
    tag:el.tagName.toLowerCase(),text:(el.innerText||el.value||"").trim(),
    role:el.getAttribute("role")||(el.tagName.toLowerCase()==="a"?"link":el.tagName.toLowerCase()),
    name:el.getAttribute("aria-label")||el.getAttribute("name")||el.getAttribute("placeholder")||el.innerText||"",
    selector:cssPath(el)}));
  return {url:location.href,title:document.title,origin:location.origin,controls};
}
async function performAction(action){
  try{
    if(action.query){const {role,name}=action.query;
      const el=[...document.querySelectorAll("*")].find(e=>(!role|| (e.getAttribute("role")||e.tagName.toLowerCase())===role)&&(!name||((e.innerText||"").includes(name)||(e.getAttribute("aria-label")||"").includes(name)||(e.getAttribute("placeholder")||"").includes(name))));
      if(el){if(action.action==="click"){el.click();return{ok:true};}if(action.action==="type"){el.focus();el.value=action.text||"";el.dispatchEvent(new Event("input",{bubbles:true}));if(action.enter){el.form?.submit();}return{ok:true};}}
    }
    if(action.selector){const el=document.querySelector(action.selector);
      if(el){if(action.action==="click"){el.click();return{ok:true};}if(action.action==="type"){el.focus();el.value=action.text||"";el.dispatchEvent(new Event("input",{bubbles:true}));if(action.enter){el.form?.submit();}return{ok:true};}}
    }
    if(action.action==="pressEnter"){document.activeElement.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter"}));return{ok:true};}
    if(action.action==="scroll"){window.scrollBy(0,action.direction==="up"?-500:500);return{ok:true};}
    if(action.action==="waitForText"){return{ok:document.body.innerText.includes(action.text)};}
    return{ok:false,error:"unknown"};
  }catch(e){return{ok:false,error:String(e)};}
}
chrome.runtime.onMessage.addListener((msg,_sender,sendResponse)=>{
  if(msg.type==="GET_SNAPSHOT"){sendResponse({ok:true,snapshot:snapshotPage()});return true;}
  if(msg.type==="PERFORM_ACTION"){performAction(msg.action).then(r=>sendResponse(r));return true;}
});
