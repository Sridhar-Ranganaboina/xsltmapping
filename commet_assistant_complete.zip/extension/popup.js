document.querySelectorAll(".tab").forEach(tab => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    document.querySelectorAll(".tab-content").forEach(c => c.style.display = "none");
    document.getElementById(tab.dataset.tab).style.display = "block";
  });
});
function log(msg) {
  const logEl = document.getElementById("log");
  const div = document.createElement("div");
  div.textContent = msg;
  logEl.appendChild(div);
  logEl.scrollTop = 99999;
}
function renderMarkdown(targetId, md) {
  try { document.getElementById(targetId).innerHTML = marked.parse(md); }
  catch { document.getElementById(targetId).textContent = md; }
}
document.getElementById("run-automation").addEventListener("click", async () => {
  const task = document.getElementById("task").value.trim();
  if (!task) return alert("Enter a task");
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.runtime.sendMessage({ type: "RUN_AUTOMATION", task, tabId: tab.id }, resp => log("Automation: " + JSON.stringify(resp)));
});
document.getElementById("run-summary").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.runtime.sendMessage({ type: "RUN_SUMMARY", tabId: tab.id }, resp => renderMarkdown("result", resp.summary||"No summary"));
});
document.getElementById("run-bookmark").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.runtime.sendMessage({ type: "RUN_BOOKMARK", bookmark:"create_change_request", tabId: tab.id }, resp => log("Bookmark: " + JSON.stringify(resp)));
});
