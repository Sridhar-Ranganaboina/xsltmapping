import re
import os
from dotenv import load_dotenv
load_dotenv()

VECTORIZERS = {
    "text2vec-openai",
    "text2vec-cohere",
}  # Needs to match with Weaviate modules
EMBEDDINGS = {"MiniLM", "OLLAMA"}  # Custom Vectors