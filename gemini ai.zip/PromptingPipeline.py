from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
from langchain.prompts import PromptTemplate,FewShotPromptTemplate
from langchain.chains.llm import LLMChain
from langchain.chains.combine_documents.stuff import StuffDocumentsChain
from langchain.chains import RetrievalQA
from redundant_filter_retriever import RedundantFilterRetriever
from langchain.llms import HuggingFacePipeline
from langchain_community.embeddings import HuggingFaceEmbeddings, OpenAIEmbeddings
from langchain.vectorstores import Chroma, Pinecone
import os
import re

class PromptingPipeline:
    def __init__(self, model_path,db_type, db_path, embeddings_type='hugging_face', chain_type='retrieval_qa', device='cpu', max_new_tokens=500):
        self.model_path = model_path
        self.db_path = db_path
        self.embeddings_type = embeddings_type
        self.chain_type = chain_type
        self.device = device
        self.max_new_tokens = max_new_tokens
        self.tokenizer = AutoTokenizer.from_pretrained(model_path)
        self.model = AutoModelForCausalLM.from_pretrained(model_path)
        self.pipe = pipeline("text-generation", model=self.model, tokenizer=self.tokenizer, max_new_tokens=max_new_tokens, device_map='auto')
        self.llm = HuggingFacePipeline(pipeline=self.pipe)
        if embeddings_type == 'hugging_face':
            self.embeddings = HuggingFaceEmbeddings(model_name=model_path, model_kwargs={'device': device})
        elif embeddings_type == 'openai':
            self.embeddings = OpenAIEmbeddings(model_name=model_path)
        else:
            raise ValueError("Invalid embeddings type. Choose between 'hugging_face' and 'openai'.")
        if db_type == 'chroma':
            self.db = Chroma(persist_directory=db_path, embedding_function=self.embeddings)
        elif db_type == 'pinecone':
            self.db = Pinecone(persist_directory=db_path, embedding_function=self.embeddings)
        else:
            raise ValueError("Invalid database type. Choose between 'chroma' and 'pinecone'.")
        self.retriever = RedundantFilterRetriever(embeddings=self.embeddings, chroma=self.db)

    def extract_answer(self, result):
        match = re.search(r'Answer:\s*(.*)', result)
        if match:
            return match.group(1)
        return None
    def _init_chain(self, prompt_template):
        llm_chain = LLMChain(llm=self.llm, prompt=prompt_template, callbacks=None, verbose=True)
        combine_documents_chain = StuffDocumentsChain(
            llm_chain=llm_chain,
            document_variable_name="context",
            document_prompt=PromptTemplate(input_variables=["page_content", "source"], template="Context:\ncontent:{page_content}\nsource:{source}"),
            callbacks=None
        )
        qa = RetrievalQA(
            combine_documents_chain=combine_documents_chain,
            callbacks=None,
            verbose=True,
            retriever=self.retriever,
            return_source_documents=True
        )
        return qa
    

    def _init_few_shot_chain(self):
        few_shot_examples = [
            {
                "context": "Context: JPMorgan Chase & Co. reported a net income of $48.3 billion for the year 2023.\nSource: Annual Report 2023",
                "question": "What was the JPMC net income in 2023?",
                "answer": "JPMC's net income in 2023 was $48.3 billion.\nSources:\n- Annual Report 2023"
            },
            {
                "context": "Context: According to the latest census, the population of the United States is approximately 331 million people.\nSource: U.S. Census Bureau",
                "question": "How many people live in US?",
                "answer": "The population of the United States is approximately 331 million people.\nSources:\n- U.S. Census Bureau"
            }
            # Add more examples as needed
        ]
        
        few_shot_template = FewShotPromptTemplate(
            examples=few_shot_examples,
            example_prompt=PromptTemplate(
                input_variables=["context", "question", "answer"],
                template="Context:\n{context}\n\nQuestion: {question}\nAnswer: {answer}\n"
            ),
            prefix="Use the following pieces of context to answer the question at the end. Follow these rules:\n"
                   "1. If the question requests links, only return the source links.\n"
                   "2. If you don't know the answer, say **I can't find the final answer but you may want to check the following links** and add the source links.\n"
                   "3. If you find the answer, write it concisely and add the sources directly used to derive the answer. Exclude irrelevant sources.\n\n",
            suffix="Context:\n{context}\n\nQuestion: {question}\nHelpful Answer:",
            input_variables=["context", "question"]
        )
        qa=self._init_chain(few_shot_template)        
        return qa

    def _init_zero_shot_chain(self, prompt_template):
        system_prompt_template = """Use the following pieces of context to answer the question at the end.

        {context}

        Question: {question}
        Helpful Answer:"""
        QA_CHAIN_PROMPT = PromptTemplate.from_template(system_prompt_template) # prompt_template defined above

        qa=self._init_chain(QA_CHAIN_PROMPT)        
        return qa
    def _init_system_prompt_chain(self, prompt_template):
        system_prompt_template = """Use the following pieces of context to answer the question at the end. Please follow the following rules:
        1. If the question is to request links, please only return the source links with no answer.
        2. If you don't know the answer, don't try to make up an answer. Just say **I can't find the final answer but you may want to check the following links** and add the source links as a list.
        3. If you find the answer, write the answer in a concise way and add the list of sources that are **directly** used to derive the answer. Exclude the sources that are irrelevant to the final answer.

        {context}

        Question: {question}
        Helpful Answer:"""
        QA_CHAIN_PROMPT = PromptTemplate.from_template(system_prompt_template) # prompt_template defined above

        qa=self._init_chain(QA_CHAIN_PROMPT)        
        return qa
    def _init_tot_chain(self, prompt_template):
        tot_template = """
        You are an expert tasked with answering complex questions based on provided context. Use a step-by-step approach to break down the problem and arrive at the answer. Follow these steps:

        1. Analyze the context and extract relevant information.
        2. Use the information to form an intermediate thought.
        3. Refine the thought to get closer to the answer.
        4. Repeat until you derive the final answer.

        Context:
        {context}

        Question: {question}

        Step 1: Analyze the context.
        Thought 1: {{thought1}}

        Step 2: Use Thought 1 to form an intermediate thought.
        Thought 2: {{thought2}}

        Step 3: Refine Thought 2 to get closer to the answer.
        Thought 3: {{thought3}}

        Step 4: Derive the final answer from Thought 3.
        Final Answer: {{final_answer}}
        """

        tot_prompt = PromptTemplate(
            input_variables=["context", "question", "thought1", "thought2", "thought3", "final_answer"],
            template=tot_template
        )

        qa=self._init_chain(tot_prompt)        
        return qa

    def query(self):
     
        # Initialize the appropriate chain based on the selected type
        if self.chain_type == 'system_prompt':
            chain = self._init_system_prompt_chain()
        elif self.chain_type == 'few_shot':
            chain = self._init_few_shot_chain()
        elif self.chain_type == 'zero_shot':
            chain = self._init_zero_shot_chain()
        elif self.chain_type == 'tot':
            chain = self._init_tot_chain()
        else:
            raise ValueError("Invalid chain type. Choose between 'retrieval_qa', 'few_shot', 'zero_shot', and 'tot'.")
        # zero,few, system prompts examples:
        query="What was the JPMC net income in 2023?"
        results = chain(query)
        res = self.extract_answer(results.get('result'))
        print(f'Question: {query} \n Answer: {res}')
        # tot_prompt example
        input_data = {
        "context": "JPMorgan Chase & Co. reported a net income of $48.3 billion for the year 2023.",
        "question": "What was the JPMC net income in 2023?",
        "thought1": "",
        "thought2": "",
        "thought3": "",
        "final_answer": ""
    }
        query = f"{input_data['context']} {input_data['question']} {input_data['thought1']} {input_data['thought2']} {input_data['thought3']} {input_data['final_answer']}"     
        results = chain(query)
        print(results)
        res=self.extract_answer(results.get('result'))
        print(f'Question:{query} \n Answer:{res}')
