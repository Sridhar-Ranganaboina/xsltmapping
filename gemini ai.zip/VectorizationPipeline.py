# train.py
import os
from langchain_community.document_loaders import PyPDFLoader,CSVLoader,TextLoader
from langchain.text_splitter import CharacterTextSplitter, RecursiveCharacterTextSplitter
from langchain.vectorstores import Chroma, Pinecone  # Import other storage methods as needed
from langchain_community.embeddings import HuggingFaceEmbeddings, OpenAIEmbeddings  # Import other embeddings as needed

class VectorizationPipeline:
    def __init__(self, document_path, model_name, chunk_size=500, chunk_overlap=0, persist_directory='emb'):
        self.document_path = document_path
        self.model_name = model_name
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.persist_directory = persist_directory
    def load_document(self, document_type='pdf'):  # Add document_type parameter
        if document_type == 'pdf':
            loader = PyPDFLoader(self.document_path)
        elif document_type == 'csv':
            loader = CSVLoader(self.document_path)
        elif document_type == 'txt':
            loader = TextLoader(self.document_path)
        else:
            raise ValueError("Invalid document type. Supported types are 'pdf', 'csv', and 'txt'.")        
        
        return loader
    def split_text(self,loader, splitter_type='recursive'):  # Add splitter_type parameter
        if splitter_type == 'character':
            text_splitter = CharacterTextSplitter(
                separators="\n",
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap
            )
        elif splitter_type == 'recursive':
            text_splitter = RecursiveCharacterTextSplitter(
                separators="\n",
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap
            )
        else:
            raise ValueError("Invalid splitter type. Supported types are 'character' and 'recursive'.")
        
        #loader = PyPDFLoader(self.document_path)
        documents = loader.load_and_split(text_splitter=text_splitter)
        return documents

    def embed_and_store(self, documents, embeddings_provider, storage_type='chroma'):  # Add embeddings_provider parameter
        if embeddings_provider == 'hugging_face':
            embeddings = HuggingFaceEmbeddings(model_name=self.model_name)
        elif embeddings_provider == 'openai':
            embeddings = OpenAIEmbeddings()
        else:
            raise ValueError("Invalid embeddings provider. Supported providers are 'hugging_face' and 'openai'.")
        
        if storage_type == 'chroma':
            vector_store = Chroma.from_documents(documents=documents, embedding=embeddings, persist_directory=self.persist_directory)
        elif storage_type == 'pinecone':
            vector_store = Pinecone.from_documents(documents=documents, embedding=embeddings, persist_directory=self.persist_directory)
        else:
            raise ValueError("Invalid storage type. Supported types are 'chroma' and 'pinecone'.")
        print("Vectorization completed")
        return vector_store

    def run(self, document_type='pdf', embeddings_provider='hugging_face', storage_type='chroma', splitter_type='recursive'):  # Add document_type parameter
        loader = self.load_document(document_type=document_type)
        split_documents = self.split_text(loader=loader, splitter_type=splitter_type)  # Splitting the loaded documents
        # Optional: You can perform additional preprocessing steps here if needed
        vector_store = self.embed_and_store(split_documents, embeddings_provider, storage_type=storage_type)
        return vector_store