class Doc_Entity:
    def __init__(
        self,
        doc_name: str = "",
        doc_type: int = "",        
        user_id: int = "",
        document_path="",
    ):
        self._doc_name = doc_name
        self._doc_type = doc_type
        self._user_id = user_id
        self._document_path=document_path       
       

    @property
    def doc_name(self):
        return self._doc_name
    @property
    def doc_type(self):
        return self._doc_type
    @property
    def user_id(self):
        return self._user_id
    @property
    def document_path(self):
        return self._document_path

  