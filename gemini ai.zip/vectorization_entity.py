from chunk_entity import Chunk_Entity
from doc_entity import Doc_Entity
class Vectorization_Entity:
    def __init__(
        self,       
        chunk:Chunk_Entity=None,
        doc:Doc_Entity=None,
    ):
        

        self._chunk=chunk   
        self._doc=doc       
       



    @property
    def chunk(self):
        return self._chunk
    @property
    def doc(self):
        return self._doc

  