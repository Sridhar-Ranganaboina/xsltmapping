from chunk_entity import Chunk_Entity
from doc_entity import Doc_Entity
class Prompting_Entity:
    def __init__(
        self,
        
        llm_model_name: str = "",
        db_persist_directory: int = "",        
        user_id: int = "",        
       
    ):
       
        self._llm_model_name = llm_model_name
        self._db_persist_directory = db_persist_directory
        self._user_id = user_id      
            
       

    @property
    def embeding_model_name(self):
        return self._embeding_model_name
    @property
    def llm_model_name(self):
        return self._llm_model_name
    @property
    def db_persist_directory(self):
        return self._db_persist_directory
    @property
    def user_id(self):
        return self._user_id
 

  