from vectorization_entity import Vectorization_Entity
from prompting_entity import Prompting_Entity
class Project_Entity:
    def __init__(
        self,
        project_name:str="",
        project_id:str="",
        embeding_model_name: str = "",        
        db_persist_directory: int = "",        
        user_id: int = "",  
        prompting:Prompting_Entity=None,
        vectorization:Vectorization_Entity=None,      
       
    ):
        self._project_name=project_name
        self._project_id=project_id
        self._embeding_model_name = embeding_model_name     
        self._db_persist_directory = db_persist_directory
        self._user_id = user_id     
        self._prompting = prompting  
        self._vectorization = vectorization   

    @property
    def project_id(self):
        return self._project_id
    @property
    def project_name(self):
        return self._project_name        
    @property
    def embeding_model_name(self):
        return self._embeding_model_name

    @property
    def db_persist_directory(self):
        return self._db_persist_directory
    @property
    def user_id(self):
        return self._user_id
 

  