class Chunk_Entity:
    def __init__(
        self,
        splitter_type:str="",
        separators: str = "",
        chunk_size: int = "",
        chunk_overlap: int = "",
        doc_uuid: int = "",
        chunk_id: int = "",
    ):
        self._splitter_type = splitter_type
        self._separators = separators
        self._chunk_size = chunk_size
        self._chunk_overlap = chunk_overlap
        self._doc_uuid = doc_uuid
        self._chunk_id = chunk_id

    @property
    def splitter_type(self):
        return self._splitter_type       
    @property
    def separators(self):
        return self._separators
    @property
    def separators(self):
        return self._separators

    @property
    def chunk_overlap(self):
        return self._chunk_overlap

    @property
    def chunk_size(self):
        return self._chunk_size

   
    @property
    def doc_uuid(self):
        return self._doc_uuid

    @property
    def chunk_id(self):
        return self._chunk_id

    def set_chunk_id(self, id):
        self._chunk_id = id
    def set_doc_uuid(self, uuid):
        self._doc_uuid = uuid

    def set_separators(self, separators):
        self._separators = separators

    def set_chunk_overlap(self, chunk_overlap):
        self._chunk_overlap = chunk_overlap

    def set_chunk_size(self, chunk_size):
        self._chunk_size = chunk_size

    def to_dict(self) -> dict:
        """Convert the Chunk object to a dictionary."""
        return {
            "chunk_id": self.chunk_id,
            "doc_uuid": self.doc_uuid,
            "separators": self.separators,
            "chunk_overlap": self.chunk_overlap,
            "chunk_size": self.chunk_size,
           
        }

    @classmethod
    def from_dict(cls, data: dict):
        """Construct a Chunk object from a dictionary."""
        chunk = cls(
            chunk_id=data.get("chunk_id", ""),
            doc_uuid=data.get("doc_uuid", ""),
            separators=data.get("separators", ""),
            chunk_overlap=data.get("chunk_overlap", ""),
            chunk_size=data.get("chunk_size", ""),
        )
        chunk.set_chunk_id(data.get("chunk_id", 0))
        chunk.set_doc_uuid(data.get("doc_uuid", None))
        chunk.set_separators(data.get("separators", 0))
        chunk.set_chunk_overlap(data.get("chunk_overlap", 0))
        chunk.set_chunk_size(data.get("chunk_size", 0))
        return chunk