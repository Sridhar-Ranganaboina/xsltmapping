
const BACKEND = 'http://localhost:8000';

// Utility sleep helper
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Capture a snapshot of the current tab (via content script)
function getSnapshotFromActiveTab() {
  return new Promise(async (resolve) => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.tabs.sendMessage(tab.id, { type: 'GET_SNAPSHOT' }, (resp) => {
      resolve({ snapshot: (resp && resp.snapshot) || null, tabId: tab.id, url: tab?.url });
    });
  });
}

// POST to backend helper
async function sendToBackend(path, payload) {
  const res = await fetch(`${BACKEND}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  return res.json();
}

// Execute a list of steps and replan after each via /next
async function executePlan(steps, tabId) {
  for (const s of steps) {
    // perform action in content script
    await new Promise(resolve => {
      chrome.tabs.sendMessage(tabId, { type: 'PERFORM_ACTION', action: s }, (r) => resolve(r));
    });
    // wait briefly
    await sleep(800);
    // fetch new snapshot
    const snap = await new Promise(resolve => {
      chrome.tabs.sendMessage(tabId, { type: 'GET_SNAPSHOT' }, (r) => resolve((r && r.snapshot) || null));
    });
    // send explore links to backend (optional)
    try {
      await fetch(`${BACKEND}/explore`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ current_url: snap.url, links: snap.links || [] })
      });
    } catch (e) {}
    // get next plan from backend
    try {
      const nextPlan = await sendToBackend('/next', { last_step: s, dom: snap.controls, current_url: snap.url, prompt: '' });
      if (nextPlan && nextPlan.steps && nextPlan.steps.length) {
        await executePlan(nextPlan.steps, tabId);
      }
    } catch (err) {
      console.error('Error fetching next plan:', err);
    }
    if (s.action === 'done') return;
  }
}

// Handle automation or summary intent
async function runIntent(prompt) {
  const { snapshot, tabId } = await getSnapshotFromActiveTab();
  if (!snapshot) return { ok: false, error: 'no-snapshot' };
  // Call intent endpoint with task and context
  try {
    const resp = await sendToBackend('/intent', {
      task: prompt,
      context: {
        url: snapshot.url,
        title: snapshot.title,
        controls: snapshot.controls,
        text: snapshot.text
      }
    });
    // If result contains a summary, return it directly
    if (resp && resp.result) {
      // summarizer returns object, pick summary if present
      const summary = typeof resp.result === 'string' ? resp.result : resp.result.summary || JSON.stringify(resp.result);
      return { ok: true, summary };
    }
    // Automation: run steps
    if (resp && resp.steps) {
      await executePlan(resp.steps, tabId);
      return { ok: true, status: 'Automation completed' };
    }
    return { ok: true, status: resp && resp.status ? resp.status : 'No steps generated' };
  } catch (err) {
    return { ok: false, error: String(err) };
  }
}

// Current task string (legacy)
let currentTask = null;

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    // Unified intent handler
    if (msg.type === 'RUN_INTENT') {
      currentTask = msg.prompt;
      const result = await runIntent(currentTask);
      sendResponse(result);
      return;
    }
    // Legacy start task (automation only)
    if (msg.type === 'START_TASK') {
      currentTask = msg.prompt;
      const { snapshot, tabId, url } = await getSnapshotFromActiveTab();
      const plan = await sendToBackend('/plan', { prompt: currentTask, dom: snapshot.controls, start_url: url });
      if (plan && plan.steps) {
        await executePlan(plan.steps, tabId);
      }
      sendResponse({ ok: true });
      return;
    }
    // Run a specific agent (wired automation)
    if (msg.type === 'RUN_AGENT') {
      const { agent, context } = msg;
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      try {
        const res = await fetch(`${BACKEND}/run_agent`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ agent, context })
        });
        const data = await res.json();
        if (data && data.result && data.result.actions) {
          for (const a of data.result.actions) {
            await new Promise(resolve => {
              chrome.tabs.sendMessage(tab.id, { type: 'PERFORM_ACTION', action: a }, (r) => resolve(r));
            });
            await sleep(800);
          }
        }
        sendResponse({ ok: true, result: data });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
      return;
    }
    // Summarize current page via backend summarizer (legacy)
    if (msg.type === 'SUMMARIZE') {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      chrome.tabs.sendMessage(tab.id, { type: 'GET_SNAPSHOT' }, async (resp) => {
        if (!resp || !resp.snapshot) {
          sendResponse({ ok: false });
          return;
        }
        try {
          const j = await sendToBackend('/summarize', { context: { url: resp.snapshot.url, title: resp.snapshot.title, controls: resp.snapshot.controls, text: resp.snapshot.text } });
          sendResponse({ ok: true, summary: j });
        } catch (e) {
          sendResponse({ ok: false, error: String(e) });
        }
      });
      return;
    }
    sendResponse({ ok: false });
  })();
  return true;
});
