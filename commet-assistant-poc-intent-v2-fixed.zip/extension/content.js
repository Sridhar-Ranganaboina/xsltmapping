// content.js - DOM snapshot and action executor for Commet Assistant
// This script runs in the context of web pages. It snapshots semantic controls and executes actions.

// Generate a CSS selector path for an element (fallback)
function cssPath(el) {
  if (!el || el.nodeType !== 1) return '';
  if (el.id) return `#${CSS.escape(el.id)}`;
  const parts = [];
  while (el && el.nodeType === 1 && el !== document.body) {
    let selector = el.nodeName.toLowerCase();
    if (el.classList && el.classList.length) {
      selector += '.' + [...el.classList].map(c => CSS.escape(c)).join('.');
    }
    const parent = el.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children).filter(n => n.nodeName === el.nodeName);
      if (siblings.length > 1) {
        const index = siblings.indexOf(el) + 1;
        selector += `:nth-of-type(${index})`;
      }
    }
    parts.unshift(selector);
    el = el.parentElement;
  }
  return parts.length ? parts.join(' > ') : 'body';
}

// Derive a human-friendly name from various attributes
function getName(el) {
  const aria = el.getAttribute && el.getAttribute('aria-label');
  if (aria) return aria.trim();
  const placeholder = el.getAttribute && el.getAttribute('placeholder');
  if (placeholder) return placeholder.trim();
  const title = el.getAttribute && el.getAttribute('title');
  if (title) return title.trim();
  const alt = el.getAttribute && el.getAttribute('alt');
  if (alt) return alt.trim();
  const text = el.innerText && el.innerText.trim();
  if (text) return text;
  return '';
}

// Determine a role for an element
function roleOf(el) {
  const role = el.getAttribute && el.getAttribute('role');
  if (role) return role;
  const tag = el.tagName && el.tagName.toLowerCase();
  const type = el.getAttribute && el.getAttribute('type');
  if (tag === 'a') return 'link';
  if (tag === 'button' || type === 'button' || type === 'submit') return 'button';
  if (tag === 'input' || tag === 'textarea') return 'textbox';
  return null;
}

// Snapshot the page: collect controls and metadata
function snapshotPage() {
  const nodes = Array.from(document.querySelectorAll('a[href], button, input, textarea, select, [role]'));
  const controls = nodes.map(el => ({
    tag: el.tagName.toLowerCase(),
    text: (el.innerText || el.value || '').trim(),
    placeholder: el.getAttribute && el.getAttribute('placeholder') || null,
    role: roleOf(el),
    href: el.getAttribute && el.getAttribute('href') || null,
    selector: cssPath(el),
    name: getName(el),
    type: el.getAttribute && el.getAttribute('type') || null,
    testid: el.getAttribute && el.getAttribute('data-testid') || null
  }));
  const links = controls.filter(c => c.tag === 'a' && c.href).map(c => new URL(c.href, location.href).href);
  return {
    url: window.location.href,
    title: document.title,
    origin: window.location.origin,
    controls,
    links: Array.from(new Set(links)),
    text: document.body && document.body.innerText ? document.body.innerText.slice(0, 20000) : ''
  };
}

// Resolve a query object to an element
function resolveQuery(query) {
  if (!query) return null;
  const role = query.role;
  const name = query.name && query.name.toLowerCase();
  const textQ = query.text && query.text.toLowerCase();
  let candidates = Array.from(document.querySelectorAll('*'));
  candidates = candidates.filter(el => {
    const r = roleOf(el);
    if (role && r !== role) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0;
  });
  let best = null, bestScore = -1;
  for (const el of candidates) {
    const nm = getName(el).toLowerCase();
    const txt = (el.innerText || '').toLowerCase();
    let score = 0;
    if (name && nm.includes(name)) score += 5;
    if (textQ && txt.includes(textQ)) score += 3;
    if (name && txt.includes(name)) score += 2;
    if (score > bestScore) {
      bestScore = score;
      best = el;
    }
  }
  return best;
}

// Perform an action based on the step
async function performAction(action) {
  try {
    if (!action || !action.action) return { ok: false, error: 'invalid action' };
    // Helper to resolve element via selector or query
    const resolve = () => {
      if (action.selector) {
        const el = document.querySelector(action.selector);
        if (el) return el;
      }
      if (action.query) {
        const el = resolveQuery(action.query);
        if (el) return el;
      }
      return null;
    };
    switch (action.action) {
      case 'navigate':
        if (action.url) {
          window.location.href = action.url;
          return { ok: true };
        }
        return { ok: false, error: 'no-url' };
      case 'click': {
        const el = resolve();
        if (!el) return { ok: false, error: 'not-found' };
        el.scrollIntoView({ block: 'center', inline: 'center' });
        el.click();
        return { ok: true };
      }
      case 'type': {
        const el = resolve();
        if (!el) return { ok: false, error: 'not-found' };
        el.focus();
        if ('value' in el) {
          el.value = action.text || '';
          el.dispatchEvent(new Event('input', { bubbles: true }));
        } else {
          el.innerText = action.text || '';
        }
        if (action.enter) {
          const evt = new KeyboardEvent('keydown', { key: 'Enter', bubbles: true });
          el.dispatchEvent(evt);
        }
        return { ok: true };
      }
      case 'pressEnter': {
        const el = resolve() || document.activeElement;
        if (!el) return { ok: false, error: 'no-target' };
        const evt = new KeyboardEvent('keydown', { key: 'Enter', bubbles: true });
        el.dispatchEvent(evt);
        return { ok: true };
      }
      case 'waitForText': {
        const timeout = action.timeout || 8000;
        const text = action.text || '';
        const start = Date.now();
        while (Date.now() - start < timeout) {
          if (document.body && document.body.innerText.includes(text)) return { ok: true };
          await new Promise(r => setTimeout(r, 200));
        }
        return { ok: false, error: 'wait-timeout' };
      }
      case 'scroll': {
        const times = action.times || 1;
        for (let i = 0; i < times; i++) {
          window.scrollBy(0, action.direction === 'up' ? -600 : 600);
          await new Promise(r => setTimeout(r, 200));
        }
        return { ok: true };
      }
      case 'done':
        return { ok: true, done: true };
      default:
        return { ok: false, error: 'unknown-action' };
    }
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}

// Message listener for content script
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg.type === 'GET_SNAPSHOT') {
      sendResponse({ ok: true, snapshot: snapshotPage() });
      return;
    }
    if (msg.type === 'PERFORM_ACTION') {
      const res = await performAction(msg.action);
      sendResponse(res);
      return;
    }
    // Legacy summarization request: capture context for summarizer
    if (msg.type === 'SUMMARIZE') {
      const snap = snapshotPage();
      sendResponse({ ok: true, context: {
        url: snap.url,
        title: snap.title,
        controls: snap.controls,
        text: snap.text
      } });
      return;
    }
    sendResponse({ ok: false, error: 'unknown-message' });
  })();
  return true;
});