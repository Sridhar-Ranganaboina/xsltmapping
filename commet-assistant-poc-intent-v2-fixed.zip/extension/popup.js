// extension/popup.js - Unified run handler with LLM intent classification
document.addEventListener('DOMContentLoaded', async () => {
  const runBtn = document.getElementById('run');
  const status = document.getElementById('status');
  const taskEl = document.getElementById('task');
  const bookmarksEl = document.getElementById('bookmarks');
  const runBookmark = document.getElementById('run-bookmark');

  // Unified Run button handler: delegate to background for intent classification and execution
  runBtn.addEventListener('click', () => {
    const prompt = taskEl.value.trim();
    if (!prompt) { alert('Enter a task'); return; }
    status.textContent = 'Running...';
    chrome.runtime.sendMessage({ type: 'RUN_INTENT', prompt }, (resp) => {
      if (!resp) {
        status.textContent = 'Error running task';
        return;
      }
      if (resp.summary) {
        // Display summary
        status.textContent = resp.summary;
      } else if (resp.status) {
        status.textContent = resp.status;
      } else if (resp.ok) {
        status.textContent = 'Completed';
      } else {
        status.textContent = 'Failed';
      }
    });
  });

  // Load bookmarks from backend for bookmark dropdown
  async function loadBookmarks() {
    try {
      const res = await fetch('http://localhost:8000/bookmarks');
      const j = await res.json();
      bookmarksEl.innerHTML = '';
      (j.bookmarks || []).forEach(b => {
        const o = document.createElement('option');
        o.value = b.id; o.textContent = b.name;
        bookmarksEl.appendChild(o);
      });
    } catch (e) {
      bookmarksEl.innerHTML = '<option>Error loading</option>';
    }
  }
  await loadBookmarks();

  // Run bookmark by invoking its agent on backend and executing returned actions
  runBookmark.addEventListener('click', async () => {
    const id = bookmarksEl.value;
    if (!id) return alert('Choose bookmark');
    status.textContent = 'Running bookmark...';
    try {
      // Get current page URL to pass as context for some bookmarks
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const url = tab && tab.url ? tab.url : '';
      const res = await fetch('http://localhost:8000/run_bookmark', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, url })
      });
      const data = await res.json();
      // If bookmark returns actions, execute them sequentially
      if (data && data.result && data.result.actions) {
        for (const a of data.result.actions) {
          await new Promise(resolve => {
            chrome.tabs.sendMessage(tab.id, { type: 'PERFORM_ACTION', action: a }, (r) => resolve(r));
          });
          await new Promise(r => setTimeout(r, 800));
        }
        status.textContent = 'Bookmark completed';
      } else {
        status.textContent = 'Bookmark executed';
      }
    } catch (e) {
      console.error('Run bookmark error', e);
      status.textContent = 'Bookmark failed';
    }
  });
});