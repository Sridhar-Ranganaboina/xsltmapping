
(function () {
  const BACKEND = window.COMMET_BACKEND || 'http://localhost:8000';
  function cssEscape(s){ try{ return CSS.escape(s); }catch(e){ return s; } }
  function cssPath(el){ if(!el||el.nodeType!==1) return ''; if(el.id) return `#${cssEscape(el.id)}`; const parts=[]; while(el&&el.nodeType===1&&el!==document.body){ let sel = el.nodeName.toLowerCase(); if(el.classList&&el.classList.length){ sel += '.' + [...el.classList].map(c=>c.trim()).filter(Boolean).join('.'); } const parent = el.parentElement; if(parent){ const siblings = Array.from(parent.children).filter(n=>n.nodeName===el.nodeName); if(siblings.length>1){ sel += `:nth-of-type(${siblings.indexOf(el)+1})`; } } parts.unshift(sel); el = el.parentElement; } return parts.join(' > '); }
  function snapshotPage(){ const controls = Array.from(document.querySelectorAll('a[href], button, input, textarea, select, [role]')).map(el=>({ tag: el.tagName.toLowerCase(), text: (el.innerText||el.value||'').trim(), selector: cssPath(el), href: el.getAttribute('href')||null })); const links = controls.filter(c=>c.tag==='a'&&c.href).map(c=>new URL(c.href, location.href).href); return { url: location.href, title: document.title, origin: location.origin, controls, links: Array.from(new Set(links)) }; }
  async function callBackend(path, payload){ const res = await fetch(BACKEND+path, { method: 'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify(payload) }); return res.json(); }
  // Create a floating container that docks to the right side of the viewport and takes up roughly
  // one quarter of the width. Setting top:0 and height:100vh ensures the panel spans the full
  // height of the page. A high z-index keeps it above page content. The inner root takes
  // 100% of the container size so the controls can flex vertically.
  const container = document.createElement('div');
  // Position the panel at the top-right corner and stretch it to full height. We use
  // percentages for width and height so the panel always occupies roughly a
  // quarter of the viewport and spans the full height.
  container.style.position = 'fixed';
  container.style.top = '0';
  container.style.bottom = '0';
  container.style.right = '0';
  container.style.width = '25%';
  container.style.height = '100%';
  container.style.zIndex = '2147483647';
  container.innerHTML = `
    <div id="commet-root" style="width:100%;height:100%;font-family:Arial;background:#fff;box-shadow:0 8px 24px rgba(0,0,0,0.2);display:flex;flex-direction:column;">
      <div style="padding:8px;display:flex;gap:6px;">
        <input id="commet-task" placeholder="Ask assistant" style="flex:1;padding:8px;border:1px solid #ddd;border-radius:4px"/>
        <button id="commet-start" style="padding:8px 10px;border:none;background:#0b63ff;color:#fff;border-radius:4px">Run</button>
      </div>
      <div style="padding:0 8px 8px 8px;display:flex;align-items:center;gap:8px;">
        <button id="commet-sum" style="padding:6px 8px">Summarize</button>
        <select id="commet-bookmarks" style="flex:1"></select>
      </div>
      <div id="commet-log" style="flex:1;overflow:auto;padding:8px;font-size:13px;color:#222;border-top:1px solid #eee;"></div>
    </div>`;
  document.body.appendChild(container);
  const logEl = container.querySelector('#commet-log'); function log(s){ const n=document.createElement('div'); n.textContent=s; logEl.appendChild(n); logEl.scrollTop=1e9; }
  async function runTask(){ const prompt = container.querySelector('#commet-task').value.trim(); if(!prompt){ alert('Enter a task'); return; } log('Snapshotting DOM...'); const snap = snapshotPage(); log(`Sending to planner: ${prompt}`); try{ const plan = await callBackend('/plan', { prompt, dom: snap.controls, start_url: snap.url }); log('Plan received: ' + JSON.stringify(plan.steps || plan, null, 2)); for(const s of (plan.steps||[])){ log(`Executing: ${s.action} ${s.selector||s.url||''}`); if(s.action==='navigate'){ location.href = s.url; await new Promise(r=>setTimeout(r,3000)); } else if(s.action==='click'){ const el = document.querySelector(s.selector); if(!el){ log('selector not found: '+s.selector); continue; } el.scrollIntoView({ block: 'center' }); el.click(); await new Promise(r=>setTimeout(r,800)); } else if(s.action==='type'){ const el = document.querySelector(s.selector) || document.querySelector('textarea, input[type="text"]'); if(!el){ log('type target not found'); continue; } el.focus(); el.value = s.text || ''; el.dispatchEvent(new Event('input',{ bubbles:true })); await new Promise(r=>setTimeout(r,400)); } else if(s.action==='waitForText'){ const timeout = s.timeout||8000; const start = Date.now(); while(Date.now()-start < timeout){ if(document.body.innerText.includes(s.text)) break; await new Promise(r=>setTimeout(r,200)); } } else if(s.action==='scroll'){ for(let i=0;i<(s.times||1);i++){ window.scrollBy(0,s.direction==='up'?-600:600); await new Promise(r=>setTimeout(r,300)); } } else if(s.action==='done'){ log('Plan done'); } try{ const newSnap = snapshotPage(); const next = await callBackend('/next', { last_step: s, dom: newSnap.controls, current_url: newSnap.url, prompt }); if(next && next.steps && next.steps.length){ plan.steps = next.steps.concat(plan.steps.slice(plan.steps.indexOf(s)+1)); } }catch(e){ log('next step call failed: '+e.message); } } log('Task completed (PoC)'); }catch(e){ log('Planner call failed: '+e.message); } }
  container.querySelector('#commet-start').addEventListener('click', runTask);
  container.querySelector('#commet-sum').addEventListener('click', async ()=>{ log('Snapshotting for summary...'); const snap = snapshotPage(); const text = document.body && document.body.innerText ? document.body.innerText.slice(0,20000) : ''; const res = await callBackend('/summarize', { context: { url: snap.url, title: snap.title, controls: snap.controls, text } }); if(res && res.summary){ log('Summary: ' + (typeof res.summary === 'string' ? res.summary : JSON.stringify(res.summary))); if(res.highlights && res.highlights.length) log('Highlights: ' + res.highlights.join(' | ')); } else { log('No summary returned'); } });
  async function loadBookmarks(){ try{ const res = await fetch(BACKEND + '/bookmarks'); const j = await res.json(); const sel = container.querySelector('#commet-bookmarks'); sel.innerHTML = ''; (j.bookmarks||[]).forEach(b=>{ const o=document.createElement('option'); o.value=b.id; o.textContent=b.name; sel.appendChild(o); }); }catch(e){} }
  loadBookmarks();
  window.CommetWidget = { run: runTask, snapshotPage };
})();
