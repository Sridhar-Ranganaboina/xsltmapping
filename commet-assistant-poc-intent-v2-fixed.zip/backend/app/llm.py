"""
LLM builder module.

This module provides a `build_chat_llm` function that returns a LangChain Chat model configured
for Azure OpenAI with bearer token authentication.
It uses `AzureChatOpenAI` from `langchain_openai` and injects the bearer token into the
Authorization header.  The model parameters (endpoint, version, deployment) are read from
environment variables or `app.settings`.

If `langchain_openai` is not installed, this module raises a RuntimeError when called.
"""

import os
import ssl
import certifi
import httpx
from typing import Optional
from .settings import settings

try:
    # We use the langchain_openai package which includes AzureChatOpenAI
    from langchain_openai import AzureChatOpenAI
except Exception:
    AzureChatOpenAI = None  # type: ignore


def build_chat_llm(bearer_token: Optional[str] = None) -> "AzureChatOpenAI":
    """Create an AzureChatOpenAI instance for interacting with the Azure OpenAI API.

    The bearer token is used for Authorization; it can be provided explicitly or
    pulled from the OPENAI_API_KEY environment variable or settings.openai_api_key.

    Returns:
        An instance of AzureChatOpenAI configured for the current environment.

    Raises:
        RuntimeError: If langchain_openai is not installed.
    """
    if AzureChatOpenAI is None:
        raise RuntimeError(
            "langchain_openai is not installed; please install it to use AzureChatOpenAI"
        )
    # Determine the token to use
    token = (
        bearer_token
        or getattr(settings, 'openai_api_key', None)
        or os.environ.get('OPENAI_API_KEY')
    )
    # Prepare SSL context using certifi
    ca_certs = certifi.where()
    ssl_context = ssl.create_default_context(cafile=ca_certs)
    http_client = httpx.Client(verify=ssl_context)
    # Read Azure-specific parameters
    endpoint = (
        os.environ.get('OPENAI_API_BASE')
        or getattr(settings, 'openai_api_base', None)
    )
    api_version = (
        os.environ.get('OPENAI_API_VERSION')
        or getattr(settings, 'openai_api_version', None)
    )
    deployment = (
        os.environ.get('OPENAI_DEPLOYMENT')
        or getattr(settings, 'openai_deployment', None)
    )
    # Fallback to standard OpenAI API if no endpoint provided
    # In that case, default_headers will still include bearer token
    # but azure_endpoint may be None which AzureChatOpenAI can handle if using openai.com.
    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        openai_api_version=api_version,
        deployment_name=deployment,
        openai_api_key='unused',  # not used when Authorization header provided
        openai_api_type='azure',
        max_retries=0,
        temperature=0,
        max_tokens=300,
        http_client=http_client,
        default_headers={
            'Authorization': f'Bearer {token}'
        } if token else None,
    )