
import json
from pathlib import Path
_FILE = Path('./bookmarks.json')
DEFAULTS = [
    { 'id': 'create_cr', 'name': 'Create Change Request', 'agent': 'create_change_request', 'values': {} },
]
def _read():
    if not _FILE.exists():
        _FILE.write_text(json.dumps(DEFAULTS, indent=2))
    return json.loads(_FILE.read_text())
def list_bookmarks():
    return _read()
def get_bookmark(bid):
    for b in _read():
        if b['id'] == bid:
            return b
    return None
def add_bookmark(obj):
    items = _read()
    items.append(obj)
    _FILE.write_text(json.dumps(items, indent=2))
    return obj
