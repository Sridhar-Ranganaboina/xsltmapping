
import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from .settings import settings
from .persistence import init_db, upsert_node
from .planner import generate_plan
from .traversal_manager import TraversalManager
from typing import List, Dict, Any
from .agents.base import list_agents, get_agent
from .bookmarks import list_bookmarks, get_bookmark
from .llm import build_chat_llm
import os
try:
    from langchain.schema import SystemMessage, HumanMessage
    _INTENT_LC = True
except Exception:
    _INTENT_LC = False

app = FastAPI(title='Commet PoC Planner')

app.add_middleware(
    CORSMiddleware,
    allow_origins=['*'],  # tighten for prod
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

# init db
init_db()
traversal = TraversalManager(max_depth=4)

@app.post('/plan')
async def plan_endpoint(payload: Dict[str, Any]):
    prompt = payload.get('prompt', '')
    dom = payload.get('dom', [])
    start_url = payload.get('start_url')
    if start_url:
        traversal.seed(start_url)
    plan = await generate_plan(prompt, dom)
    return plan.model_dump() if hasattr(plan, 'model_dump') else plan

@app.post('/next')
async def next_endpoint(payload: Dict[str, Any]):
    dom = payload.get('dom', [])
    last = payload.get('last_step')
    current_url = payload.get('current_url')
    prompt = payload.get('prompt', '')
    if current_url:
        upsert_node(url=current_url, title=None, origin=None)
    plan = await generate_plan(prompt or 'continue the automation', dom)
    return plan.model_dump() if hasattr(plan, 'model_dump') else plan

@app.post('/explore')
async def explore(payload: Dict[str, Any]):
    current = payload.get('current_url')
    links = payload.get('links', [])
    traversal.push_links(current_url=current, links=links, via_selector=None, depth=0)
    return {'ok': True, 'frontier_size': len(traversal.frontier)}

@app.get('/graph')
async def graph():
    return {'visited': list(traversal.visited), 'frontier': [f.url for f in traversal.frontier]}

# Agents endpoints
@app.get('/agents')
async def agents_list():
    return {'agents': list_agents()}

@app.post('/run_agent')
async def run_agent(payload: Dict[str, Any]):
    agent_name = payload.get('agent')
    context = payload.get('context', {})
    agent = get_agent(agent_name)
    if not agent:
        return {'error': 'agent-not-found', 'available': list_agents()}
    res = await agent.run(context)
    return {'agent': agent_name, 'result': res}

@app.post('/summarize')
async def summarize(payload: Dict[str, Any]):
    context = payload.get('context', {})
    agent = get_agent('summarizer')
    if not agent:
        return {'error': 'summarizer-not-available'}
    res = await agent.run(context)
    return res

@app.get('/bookmarks')
async def bookmarks():
    return {'bookmarks': list_bookmarks()}

@app.post('/run_bookmark')
async def run_bookmark(payload: Dict[str, Any]):
    bid = payload.get('id')
    bm = get_bookmark(bid)
    if not bm:
        return {'error': 'bookmark-not-found'}
    agent_name = bm.get('agent')
    agent = get_agent(agent_name)
    if not agent:
        return {'error': 'agent-not-found'}
    context = {'values': bm.get('values', {}), 'url': payload.get('url')}
    res = await agent.run(context)
    return {'result': res}

def run():
    uvicorn.run('app.main:app', host=settings.host, port=settings.port, reload=True)

# Intent classification and dispatch
@app.post('/intent')
async def intent_endpoint(payload: Dict[str, Any]):
    """
    Classify the user's task as automation or summary and execute accordingly.
    Payload: { "task": str, "context": dict }
    If intent is summary, returns { status: ..., result: <summary> }.
    If intent is automation, returns { status: ..., steps: [ ... ] }.
    """
    task = (payload.get('task') or '').strip()
    context = payload.get('context') or {}
    if not task:
        return { 'status': 'empty', 'type': 'unknown' }
    # Determine intent via LLM if available
    if _INTENT_LC and (getattr(settings, 'openai_api_key', None) or 'OPENAI_API_KEY' in os.environ):
        try:
            llm = build_chat_llm()
            sys = SystemMessage(content="Classify user Task into one word: 'automation' or 'summary'.")
            user = HumanMessage(content=f"Task: {task}")
            label = llm([sys, user])
            label_text = getattr(label, 'content', str(label)).strip().lower()
            if 'summary' in label_text:
                agent = get_agent('summarizer')
                res = await agent.run(context)
                return { 'status': 'Summary complete', 'result': res }
            # default to automation
        except Exception as e:
            print('Intent classification failed:', e)
    # Heuristic fallback
    if 'summary' in task.lower() or 'summarize' in task.lower():
        agent = get_agent('summarizer')
        res = await agent.run(context)
        return { 'status': 'Summary complete', 'result': res }
    # Automation path
    dom_snapshot = context.get('controls', []) if isinstance(context, dict) else []
    plan = await generate_plan(task, dom_snapshot)
    return { 'status': 'Automation plan generated', 'steps': [ s.model_dump() for s in plan.steps ] }

if __name__ == '__main__':
    run()
