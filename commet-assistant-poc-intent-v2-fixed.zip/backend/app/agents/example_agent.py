
from .base import register, Agent

@register
class CreateChangeRequestAgent(Agent):
    name = 'create_change_request'
    description = 'Example wired automation: create change request'
    async def run(self, context):
        name = context.get('values', {}).get('name', 'Automated CR')
        steps = [
            { 'action': 'click', 'selector': 'a#create-change' },
            { 'action': 'waitForText', 'text': 'Create Change Request' },
            { 'action': 'type', 'selector': 'input#cr-title', 'text': name },
            { 'action': 'click', 'selector': 'button#submit-cr' },
            { 'action': 'waitForText', 'text': 'Request submitted' },
            { 'action': 'done' }
        ]
        return { 'actions': steps, 'status': 'ok' }
