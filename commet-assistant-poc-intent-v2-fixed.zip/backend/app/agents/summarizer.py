
from .base import register, Agent
from ..settings import settings
try:
    from ..llm import build_chat_llm
    from langchain.schema import SystemMessage, HumanMessage
    _LC = True
except Exception:
    _LC = False

@register
class SummarizerAgent(Agent):
    name = 'summarizer'
    description = 'Summarize page content (text + controls) into a concise summary.'

    async def run(self, context):
        text = context.get('text') or ''
        controls = context.get('controls', [])
        if _LC and (getattr(settings, 'openai_api_key', None) or 'OPENAI_API_KEY' in __import__('os').environ):
            try:
                llm = build_chat_llm()
                sys = SystemMessage(content='You are a helpful summarizer. Provide JSON: {"summary": "...", "highlights": [...]}')
                user = HumanMessage(content=f"URL: {context.get('url')}\nTitle: {context.get('title')}\nText:\n{text[:4000]}")
                resp = llm([sys, user])
                if isinstance(resp, list):
                    content = getattr(resp[0], 'content', str(resp[0]))
                else:
                    content = getattr(resp, 'content', str(resp))
                import json
                parsed = json.loads(content) if content.strip().startswith('{') else {'summary': content}
                return {'summary': parsed.get('summary', content), 'highlights': parsed.get('highlights', [])}
            except Exception as e:
                print('LangChain summarizer failed:', e)
        if text and len(text) > 200:
            snippet = text.strip().replace('\n', ' ')[:800]
            summary = snippet
        else:
            pieces = []
            for c in controls[:50]:
                t = (c.get('text') or '').strip()
                if t:
                    pieces.append(t)
            summary = ' | '.join(pieces[:12]) or (context.get('title') or 'No content available')
        highlights = [c.get('text') for c in controls if c.get('text')][:5] if controls else []
        return {'summary': summary, 'highlights': highlights}
