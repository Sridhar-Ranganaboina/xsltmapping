
# package initializer - ensure agents are imported so they can register themselves
from . import agents  # noqa: F401
__all__ = ['main']
