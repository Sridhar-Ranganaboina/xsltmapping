"""
Planner module for automation tasks.

Uses an LLM via LangChain to produce a short JSON plan describing how to accomplish a user task on a given page.
The planner encourages the LLM to produce a list of steps (1–6) using a strict JSON schema.  Steps may include
the following actions:
  - navigate: open a URL
  - click: click an element identified by a robust query ({"role", "name"}) or CSS selector
  - type: type text into an element; if enter=True, press Enter afterwards
  - waitForText: wait until some text appears on the page
  - scroll: scroll up or down a number of times
  - pressEnter: press the Enter key on the active element
  - done: mark completion of plan

The planner includes few-shot examples to guide the model on common patterns like searching and shopping.
"""

import json
from typing import List, Dict, Any
from .models import PlanModel, ActionModel
from .llm import build_chat_llm
from langchain.schema import SystemMessage, HumanMessage

# Strict JSON schema for the plan
SCHEMA = {
    "type": "object",
    "properties": {
        "steps": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "action": {"type": "string", "enum": ["navigate", "click", "type", "waitForText", "scroll", "pressEnter", "done"]},
                    "selector": {"type": ["string", "null"]},
                    "query": {"type": ["object", "null"]},
                    "text": {"type": ["string", "null"]},
                    "url": {"type": ["string", "null"]},
                    "times": {"type": ["number", "null"]},
                    "direction": {"type": ["string", "null"]},
                    "timeout": {"type": ["number", "null"]},
                    "enter": {"type": ["boolean", "null"]}
                },
                "required": ["action"]
            }
        }
    },
    "required": ["steps"]
}

# Few-shot examples to bias the model
FEWSHOTS = [
    (
        "search for cricket news",
        [
            {"tag": "input", "text": "", "placeholder": "Search", "selector": "input[name=q]"},
            {"tag": "button", "text": "Google Search", "selector": "input[name=btnK]"}
        ],
        {
            "steps": [
                {"action": "type", "query": {"role": "textbox", "name": "search"}, "text": "cricket news", "enter": True}
            ]
        }
    ),
    (
        "search for washing machine 5 star and add to cart",
        [
            {"tag": "input", "text": "", "placeholder": "Search Amazon", "selector": "#twotabsearchtextbox"},
            {"tag": "button", "text": "Search", "selector": "input[id=nav-search-submit-button]"}
        ],
        {
            "steps": [
                {"action": "type", "query": {"role": "textbox", "name": "search"}, "text": "washing machine 5 star", "enter": True},
                {"action": "waitForText", "text": "results"},
                {"action": "click", "query": {"role": "link", "name": "first result"}},
                {"action": "click", "query": {"role": "button", "name": "add to cart"}},
                {"action": "waitForText", "text": "Added to Cart"},
                {"action": "done"}
            ]
        }
    )
]


def _build_prompt(task: str, dom_snapshot: List[Dict[str, Any]]) -> List:
    """Construct messages for the LLM call including system prompt, few-shots, and user input."""
    system = SystemMessage(content=(
        "You are a browser automation planner. You see a simplified DOM snapshot: a list of controls (tag, text, placeholder, href, selector, role). "
        "Produce a short JSON plan (1–6 steps) describing how to accomplish the given task. "
        "Prefer using a 'query' object with keys like role and name rather than brittle CSS selectors. "
        "Use 'enter': true when typing into a search bar and pressing Enter. "
        "Use 'waitForText' to wait until the page shows certain text. "
        "Strictly return JSON that matches this schema: " + json.dumps(SCHEMA)
    ))
    msgs = [system]
    # Add few-shot pairs
    for t, dom, out in FEWSHOTS:
        msgs.append(HumanMessage(content=f"Task: {t}\nDOM: {json.dumps(dom)}"))
        msgs.append(SystemMessage(content=json.dumps(out)))
    # Append actual user task
    msgs.append(HumanMessage(content=f"Task: {task}\nDOM: {json.dumps(dom_snapshot[:200])}"))
    return msgs


def _coerce_json(text: str) -> dict:
    """Attempt to parse JSON from LLM response; fallback to empty plan."""
    try:
        return json.loads(text)
    except Exception:
        import re
        m = re.search(r'\{[\s\S]*\}$', text.strip())
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                pass
    return {"steps": []}


async def generate_plan(task: str, dom_snapshot: List[Dict[str, Any]]) -> PlanModel:
    """Generate a plan using an LLM. Returns a PlanModel instance."""
    llm = build_chat_llm()
    messages = _build_prompt(task, dom_snapshot)
    resp = llm(messages)
    content = getattr(resp, 'content', str(resp))
    parsed = _coerce_json(content)
    steps = [ActionModel(**s) for s in parsed.get("steps", [])]
    return PlanModel(steps=steps)