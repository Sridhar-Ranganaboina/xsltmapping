console.log('Commet Widget loaded');
