console.log('Commet Assistant content script loaded');
