from fastapi import FastAPI
from typing import Any, Dict
from .agents.base import list_agents, get_agent

app = FastAPI()

@app.get("/agents")
async def agents_list():
    return {"agents": list_agents()}

@app.post("/run_agent")
async def run_agent(payload: Dict[str, Any]):
    agent_name = payload.get("agent")
    context = payload.get("context", {})
    agent = get_agent(agent_name)
    if not agent:
        return {"error": "agent-not-found"}
    res = await agent.run(context)
    return {"agent": agent_name, "result": res}

@app.post("/summarize")
async def summarize(payload: Dict[str, Any]):
    context = payload.get("context", {})
    agent = get_agent("summarizer")
    if not agent:
        return {"error": "summarizer-not-found"}
    res = await agent.run(context)
    return res

# Run with: uvicorn app.main:app --reload --port 8000
