from typing import Any, Dict

_AGENT_REGISTRY: Dict[str, Any] = {}

class Agent:
    name: str = 'base'
    description: str = 'Base agent'
    def __init__(self, settings=None):
        self.settings = settings
    async def run(self, context: Dict[str, Any]) -> Dict[str, Any]:
        raise NotImplementedError()

def register(agent_cls):
    name = getattr(agent_cls, 'name', agent_cls.__name__.lower())
    _AGENT_REGISTRY[name] = agent_cls
    return agent_cls

def get_agent(name: str):
    cls = _AGENT_REGISTRY.get(name)
    return cls() if cls else None

def list_agents():
    return [{ 'name': k, 'description': getattr(v, 'description', '') } for k, v in _AGENT_REGISTRY.items()]
