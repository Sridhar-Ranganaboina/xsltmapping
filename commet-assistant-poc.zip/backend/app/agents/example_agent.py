from .base import register, Agent

@register
class ExampleAgent(Agent):
    name = 'create_change_request'
    description = 'Example agent'

    async def run(self, context):
        return { 'actions': [ { 'action': 'click', 'selector': '#submit' } ], 'status': 'ok' }
