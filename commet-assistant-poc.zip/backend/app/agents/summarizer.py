from .base import register, Agent

@register
class SummarizerAgent(Agent):
    name = 'summarizer'
    description = 'Summarize page content.'

    async def run(self, context):
        text = context.get('text') or ''
        if text:
            return { 'summary': text[:200], 'highlights': text.split()[:5] }
        return { 'summary': 'No content', 'highlights': [] }
