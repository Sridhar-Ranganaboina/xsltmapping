# Commet Assistant – Universal PoC

See chat for full instructions and diagrams.