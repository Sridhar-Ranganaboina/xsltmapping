import certifi, ssl, httpx
from typing import Optional
from settings import settings
try:
    from langchain_openai import AzureChatOpenAI
except Exception:
    AzureChatOpenAI = None

def build_chat_llm(azure_token: Optional[str] = None, azure_endpoint: Optional[str] = None,
                   model_api_version: Optional[str] = None, deployment_name: Optional[str] = None,
                   openai_api_key: Optional[str] = None):
    if AzureChatOpenAI is None:
        raise RuntimeError("langchain_openai not installed; please add it to dependencies")
    ca_certs = certifi.where()
    ssl_context = ssl.create_default_context(cafile=ca_certs)
    http_client = httpx.Client(verify=ssl_context)
    return AzureChatOpenAI(
        azure_endpoint=azure_endpoint or settings.openai_api_base,
        openai_api_version=model_api_version or settings.openai_api_version,
        deployment_name=deployment_name or settings.openai_deployment,
        openai_api_key=openai_api_key or settings.openai_api_key or "unused",
        openai_api_type="azure", temperature=0, max_tokens=500,
        http_client=http_client,
        default_headers={"Authorization": f"Bearer {azure_token}"} if azure_token else None,
    )
