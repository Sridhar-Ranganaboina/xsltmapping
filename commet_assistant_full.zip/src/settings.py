from pydantic import BaseSettings
from typing import List, Optional

class Settings(BaseSettings):
    host: str = "0.0.0.0"
    port: int = 8000
    openai_api_key: Optional[str] = None
    openai_api_base: Optional[str] = None
    openai_api_version: Optional[str] = None
    openai_deployment: Optional[str] = None
    debug: bool = True
    sqlite_url: str = "sqlite:///./commet_graph.db"
    allow_origins: List[str] = ["http://localhost:3000", "http://localhost:8000"]
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

settings = Settings()
