from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from transformers import AutoModelForCausalLM,AutoTokenizer,pipeline
from langchain.chains import RetrievalQA
from redundant_filter_retriever import RedundantFilterRetriever
from langchain.llms import HuggingFacePipeline
import langchain
import os
langchain.debug=True
import re
def extract_answer(result):
    match=re.search(r'Answer:\s*(.*)',result)
    if match:
        return match.group(1)
    return None

script_dir = os.path.dirname(os.path.abspath(__file__))
model_path = os.path.abspath(os.path.join(script_dir,"TinyLlama-1.1B-Chat-v1.0"))
model_kwargs={'device':'cpu'}
embeddings=HuggingFaceEmbeddings(model_name=model_path,model_kwargs=model_kwargs)
tokenizer=AutoTokenizer.from_pretrained(model_path)
model=AutoModelForCausalLM.from_pretrained(model_path)
db=Chroma(persist_directory='emb',embedding_function=embeddings)
retriever=RedundantFilterRetriever(embeddings=embeddings ,chroma=db)
pipe=pipeline("text-generation",model=model,tokenizer=tokenizer,max_new_tokens=500,device_map='auto')
llm=HuggingFacePipeline(pipeline=pipe)

chain=RetrievalQA.from_chain_type(
    llm=llm,
    retriever=retriever,
    chain_type="stuff" #stuff,map_reduce,refine
)


query="What was the JPMC net income in 2023"
results=chain.invoke(query)
res=extract_answer(results.get('result'))
print(f'Question:{query} \n Answer:{res}')


