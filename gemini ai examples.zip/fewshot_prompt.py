from langchain.prompts import PromptTemplate
from langchain.chains.llm import LLMChain
from langchain.chains.combine_documents.stuff import StuffDocumentsChain

from langchain.chains import RetrievalQA
from langchain_core.retrievers import BaseRetriever
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain.schema.document import Document
from typing import List
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
from langchain.chains import RetrievalQA
from redundant_filter_retriever import RedundantFilterRetriever
from langchain.llms import HuggingFacePipeline
from langchain_core.prompts.few_shot import FewShotPromptTemplate
from langchain_core.prompts.prompt import PromptTemplate
import os
import re

from langchain.chains.llm import LLMChain
from langchain.chains.combine_documents.stuff import StuffDocumentsChain
def extract_answer(result):
    match=re.search(r'Answer:\s*(.*)',result)
    if match:
        return match.group(1)
    return None
few_shot_examples = [
    {
        "context": "Context: JPMorgan Chase & Co. reported a net income of $48.3 billion for the year 2023.\nSource: Annual Report 2023",
        "question": "What was the JPMC net income in 2023?",
        "answer": "JPMC's net income in 2023 was $48.3 billion.\nSources:\n- Annual Report 2023"
    },
    {
        "context": "Context: According to the latest census, the population of the United States is approximately 331 million people.\nSource: U.S. Census Bureau",
        "question": "How many people live in US?",
        "answer": "The population of the United States is approximately 331 million people.\nSources:\n- U.S. Census Bureau"
    }
    # Add more examples as needed
]

few_shot_template = FewShotPromptTemplate(
    examples=few_shot_examples,
    example_prompt=PromptTemplate(
        input_variables=["context", "question", "answer"],
        template="Context:\n{context}\n\nQuestion: {question}\nAnswer: {answer}\n"
    ),
    prefix="Use the following pieces of context to answer the question at the end. Follow these rules:\n"
           "1. If the question requests links, only return the source links.\n"
           "2. If you don't know the answer, say **I can't find the final answer but you may want to check the following links** and add the source links.\n"
           "3. If you find the answer, write it concisely and add the sources directly used to derive the answer. Exclude irrelevant sources.\n\n",
    suffix="Context:\n{context}\n\nQuestion: {question}\nHelpful Answer:",
    input_variables=["context", "question"]
)

script_dir = os.path.dirname(os.path.abspath(__file__))
model_path = os.path.abspath(os.path.join(script_dir, "TinyLlama-1.1B-Chat-v1.0"))
model_kwargs = {'device': 'cpu'}
embeddings = HuggingFaceEmbeddings(model_name=model_path, model_kwargs=model_kwargs)
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForCausalLM.from_pretrained(model_path)
db = Chroma(persist_directory='emb', embedding_function=embeddings)
retriever = RedundantFilterRetriever(embeddings=embeddings, chroma=db)
pipe = pipeline("text-generation", model=model, tokenizer=tokenizer, max_new_tokens=500, device_map='auto')
llm = HuggingFacePipeline(pipeline=pipe)
retriever = RedundantFilterRetriever(embeddings=embeddings, chroma=db)
llm_chain = LLMChain(llm=llm, prompt=few_shot_template, callbacks=None, verbose=True)
document_prompt = PromptTemplate(
        input_variables=["page_content", "source"],
        template="Context:\ncontent:{page_content}\nsource:{source}",
    )
combine_documents_chain = StuffDocumentsChain(
        llm_chain=llm_chain,
        document_variable_name="context",
        document_prompt=document_prompt,
        callbacks=None,
    )
qa = RetrievalQA(
        combine_documents_chain=combine_documents_chain,
        callbacks=None,
        verbose=True,
        retriever=retriever,
        return_source_documents=True,
    )
query="What was the JPMC net income in 2023?"
results = qa(query)
print(results)
res=extract_answer(results.get('result'))
print(f'Question:{query} \n Answer:{res}')
    