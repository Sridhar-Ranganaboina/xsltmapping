from langchain_community.document_loaders import PyPDFLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
import sys
import os

# Split text
text_splitter = RecursiveCharacterTextSplitter(
    separators="\n",
    chunk_size=500,
    chunk_overlap=0
)
# Check current working directory
print("Current Working Directory:", os.getcwd())
script_dir = os.path.dirname(os.path.abspath(__file__))
# Absolute path to the PDF file
pdf_path = os.path.abspath(os.path.join(script_dir,"annual_report_1.pdf"))
model_path = os.path.abspath(os.path.join(script_dir,"TinyLlama-1.1B-Chat-v1.0"))
if os.path.exists(pdf_path):
    loader = PyPDFLoader(pdf_path)
documents = loader.load_and_split(text_splitter=text_splitter)
#texts = text_splitter.split_documents(documents)

# Initialize embeddings
embeddings = HuggingFaceEmbeddings(model_name=model_path)
# Initialize Chroma vector store
vector_store = Chroma.from_documents(documents=documents, embedding=embeddings,persist_directory='emb')
print("Vectorization completed")
