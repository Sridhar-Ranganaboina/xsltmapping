from langchain.prompts import PromptTemplate
from langchain.chains.llm import LLMChain
from langchain.chains.combine_documents.stuff import StuffDocumentsChain

from langchain.chains import RetrievalQA
from langchain_core.retrievers import BaseRetriever
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain.schema.document import Document
from typing import List
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
from langchain.chains import RetrievalQA
from redundant_filter_retriever import RedundantFilterRetriever
from langchain.llms import HuggingFacePipeline
from langchain_core.prompts.few_shot import FewShotPromptTemplate
from langchain_core.prompts.prompt import PromptTemplate
import os
import re

from langchain.chains.llm import LLMChain
from langchain.chains.combine_documents.stuff import StuffDocumentsChain
def extract_answer(result):
    match=re.search(r'Answer:\s*(.*)',result)
    if match:
        return match.group(1)
    return None
tot_template = """
You are an expert tasked with answering complex questions based on provided context. Use a step-by-step approach to break down the problem and arrive at the answer. Follow these steps:

1. Analyze the context and extract relevant information.
2. Use the information to form an intermediate thought.
3. Refine the thought to get closer to the answer.
4. Repeat until you derive the final answer.

Context:
{context}

Question: {question}

Step 1: Analyze the context.
Thought 1: {{thought1}}

Step 2: Use Thought 1 to form an intermediate thought.
Thought 2: {{thought2}}

Step 3: Refine Thought 2 to get closer to the answer.
Thought 3: {{thought3}}

Step 4: Derive the final answer from Thought 3.
Final Answer: {{final_answer}}
"""

TOT_PROMPT = PromptTemplate(
    input_variables=["context", "question", "thought1", "thought2", "thought3", "final_answer"],
    template=tot_template
)

script_dir = os.path.dirname(os.path.abspath(__file__))
model_path = os.path.abspath(os.path.join(script_dir, "TinyLlama-1.1B-Chat-v1.0"))
model_kwargs = {'device': 'cpu'}
embeddings = HuggingFaceEmbeddings(model_name=model_path, model_kwargs=model_kwargs)
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForCausalLM.from_pretrained(model_path)
db = Chroma(persist_directory='emb', embedding_function=embeddings)
retriever = RedundantFilterRetriever(embeddings=embeddings, chroma=db)
pipe = pipeline("text-generation", model=model, tokenizer=tokenizer, max_new_tokens=500, device_map='auto')
llm = HuggingFacePipeline(pipeline=pipe)
    
# Initialize the chain with TOT prompt
llm_chain = LLMChain(llm=llm, prompt=TOT_PROMPT, callbacks=None, verbose=True)
    
document_prompt = PromptTemplate(
        input_variables=["page_content", "source"],
        template="Context:\ncontent:{page_content}\nsource:{source}",
    )
    
combine_documents_chain = StuffDocumentsChain(
        llm_chain=llm_chain,
        document_variable_name="context",
        document_prompt=document_prompt,
        callbacks=None,
    )
    
qa = RetrievalQA(
        combine_documents_chain=combine_documents_chain,
        callbacks=None,
        verbose=True,
        retriever=retriever,
        return_source_documents=True,
    )
    
# Using the new method for TOT
input_data = {
        "context": "JPMorgan Chase & Co. reported a net income of $48.3 billion for the year 2023.",
        "question": "What was the JPMC net income in 2023?",
        "thought1": "",
        "thought2": "",
        "thought3": "",
        "final_answer": ""
    }
query = f"{input_data['context']} {input_data['question']} {input_data['thought1']} {input_data['thought2']} {input_data['thought3']} {input_data['final_answer']}"     
results = qa(query)
print(results)
res=extract_answer(results.get('result'))
print(f'Question:{query} \n Answer:{res}')
    
