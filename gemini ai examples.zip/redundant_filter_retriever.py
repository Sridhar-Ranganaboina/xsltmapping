from langchain.embeddings.base import Embeddings
from langchain.vectorstores import Chroma
from langchain.schema import BaseRetriever
from langchain.embeddings import OpenAIEmbeddings
from typing import Dict, List
from langchain.schema import Document
class RedundantFilterRetriever(BaseRetriever):
    embeddings: Embeddings
    chroma: Chroma

    def get_relevant_documents(self, query:str) -> List[Document]:
        """
        Calculate embeddings for the 'query' string and perform MMR search.

        Args:
            query (str): The input query string.

        Returns:
            List[Document]: List of relevant documents.
        """
        emb = self.embeddings.embed_query(query)
        res = self.chroma.max_marginal_relevance_search_by_vector(
            embedding=emb,
            lambda_mult=0.8
        )
        return res

   
    async def get_relevant_documents_async(self, query: str) -> List[Document]:
        """
        Asynchronously calculate embeddings for the 'query' string and perform MMR search.

        Args:
            query (str): The input query string.

        Returns:
            List[Document]: List of relevant documents.
        """
        emb = self.embeddings.embed_query(query)
        res = self.chroma.max_marginal_relevance_search_by_vector(
            embedding=emb,
            lambda_mult=0.8
        )
        return res
